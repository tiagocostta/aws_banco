<h1>Passo a Passo da atividade:</h1>

1. Crie o RDS e Crie o banco de dados e também crie as tabelas para receber os csv da pasta material. obs o cod para a criação da tabela também está na pasta.

2. Crie a maquina virtual e instale o apache ta iniciar o servidor
